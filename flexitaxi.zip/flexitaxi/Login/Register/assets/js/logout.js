import { signOut} from "https://www.gstatic.com/firebasejs/9.21.0/firebase-auth.js"
import {auth } from './firebase.js'
const logout = document.querySelector('#Logout')

logout.addEventListener('click', async () => {
    // Eliminar la información de sesión del almacenamiento local
    localStorage.removeItem('userLoggedIn');
    // Redirigir al usuario a otra página
    window.location.href = "INICIO.html"; // Reemplaza "otra_pagina.html" con la URL de la página a la que deseas redirigir
  });
  