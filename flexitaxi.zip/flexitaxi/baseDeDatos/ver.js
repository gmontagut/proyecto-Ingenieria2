function ver() {
    db.collection("encomiendas").get().then((querySnapshot) => {
      const dataContainer = document.getElementById("data-container");
      dataContainer.innerHTML = ""; // Limpiar el contenedor de datos antes de agregar nuevos datos
  
      querySnapshot.forEach((doc) => {
        const div = document.createElement("div");
        div.textContent = `Recogida: ${doc.data().direccion_entrega}, Entrega: ${doc.data().direccion_recogida}, Precio: ${doc.data().precio_ofrecido}`;
        dataContainer.appendChild(div);
      });
    });
  }
    
function verViajes(){
    db.collection("viajes").get().then((querySnapshot) => {
        const dataContainer = document.getElementById("data-container");
        dataContainer.innerHTML = ""; // Limpiar el contenedor de datos antes de agregar nuevos datos
    
        querySnapshot.forEach((doc) => {
          const div = document.createElement("div");
          div.textContent = `Origen: ${doc.data().origen}, Destino: ${doc.data().destino}, Costo: ${doc.data().costo}`;
          dataContainer.appendChild(div);
        });
      });
}
