
function guardar(){
    db.collection("encomiendas").add({
        direccion_recogida: document.getElementById("recogida").value,
        direccion_entrega: document.getElementById("entrega").value,
        precio_ofrecido: document.getElementById("precio").value,
        telefono: document.getElementById("telefono").value,
        peso_paquete: document.getElementById("peso_paquete").value,
        inf_adicional_paquete: document.getElementById("info_paquete").value,
        tipo_direccion_recogida: document.getElementById("tipo_recogida").value,
        info_adicional_recogida: document.getElementById("info_recogida").value,
        tipo_direccion_entrega: document.getElementById("tipo_entrega").value,
        info_adicional_entrega: document.getElementById("info_entrega").value

    })
    .then((docRef) => {
        alert("registro exitoso");
    })
    .catch((error) => {
        alert("El se produjo un error");
    });
}

function guardarViajes(){
    db.collection("viajes").add({
        origen: directions.getOrigin().geometry.coordinates,
        destino: directions.getDestination().geometry.coordinates,
        costo: document.getElementById('costo').textContent,
        distancia:document.getElementById('distancia').textContent,
        duracion: document.getElementById('duracion').textContent
    })
    .then((docRef) => {
        alert("registro exitoso");
    })
    .catch((error) => {
        alert("El se produjo un error");
    });
}