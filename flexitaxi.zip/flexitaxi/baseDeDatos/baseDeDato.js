//import firebase from "/firebase/app";
//import "firebase/firestore";

// TODO: Replace the following with your app's Firebase project configuration
// See: https://support.google.com/firebase/answer/7015592
const firebaseConfig = {
    apiKey: "AIzaSyCmRRHHM9p-iH0te_ogTn9VDrbb4_dpS8M",
  authDomain: "flexitaxi-5fe8a.firebaseapp.com",
  projectId: "flexitaxi-5fe8a",
  storageBucket: "flexitaxi-5fe8a.appspot.com",
  messagingSenderId: "1048383531530",
  appId: "1:1048383531530:web:ade6b5e7ca6fc85b694df3"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);


// Initialize Cloud Firestore and get a reference to the service
const db = firebase.firestore();
